<html>
<head>
	<title>Login Form</title>
	<link href = "login.css" rel="stylesheet">
</head>
<body>
	<div class="login-form">
		<center>
		<h1>Login form</h1>
		
		<form action="#">
			<input type="text" name="username" placeholder="" required>
			<input type="password" name="password" placeholder="" required>
			<input type="submit" value="Login">


		</form>
	</center>

	</div>		

</body>
</html>