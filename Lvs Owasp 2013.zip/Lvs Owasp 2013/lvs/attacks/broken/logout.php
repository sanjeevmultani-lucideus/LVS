<?php
session_start();

session_destroy();


header('Location:lesson1.php');
?>