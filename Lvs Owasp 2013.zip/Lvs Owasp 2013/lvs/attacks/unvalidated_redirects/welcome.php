<html>
<body>
<center>
<video width="1400" height="700" controls autoplay controls loop>
<source src="1.mp4" type="video/mp4">
<source src="1.ogg" type="video/ogg">
</center>
</video>
</body>
</html>