<?php
system('dir');
?>